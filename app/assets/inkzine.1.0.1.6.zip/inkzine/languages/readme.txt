This theme is translation ready and the .po and .mo files are provided for all popular languages. To generate a .po file for your language, visit:

http://translate.google.com/toolkit/

and upload the en_EN.po file and translate it to a file of your langauge. Then you can use any .po to .mo convertor to create .mo file for your language. e.g. http://po2mo.net/

For more details, please read:

http://codex.wordpress.org/Translating_WordPress
http://codex.wordpress.org/WordPress_in_Your_Language
http://codex.wordpress.org/Function_Reference/load_theme_textdomain